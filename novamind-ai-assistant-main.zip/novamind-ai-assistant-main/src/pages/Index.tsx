
import React from 'react';
import { ChatInterface } from '@/components/ChatInterface';

const Index = () => {
  return <ChatInterface />;
};

export default Index;
